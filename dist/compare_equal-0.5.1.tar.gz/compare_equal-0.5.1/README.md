# Compare Equal module

This module for Python is a function for Chimera to compare if two molecules are equal.

You can compare **Python variable** of the Chimera's Molecule class or directly two **PDB files**. 

## Documentation

Here are the documention section.

## License

Here, there is the license.

## Citation

Citation section. 
